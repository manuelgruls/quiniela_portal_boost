// PowerBI SDK type definitions
import * as pbi from 'powerbi-client';

export type PowerBI = typeof pbi;

export { };